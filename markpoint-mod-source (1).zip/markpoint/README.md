# MarkPoint

مود Fabric لماين كرافت Java 1.21.11: نظام إشارات وتحديد مواقع (Ping) للتنسيق بين اللاعبين.
الوصف الكامل لصفحة Modrinth في `MODRINTH_DESCRIPTION.md`.

## البناء

1. المتطلبات: JDK 21.
2. تأكد من الإصدارات في `gradle.properties` من https://fabricmc.net/develop (اختر 1.21.11) وحدّثها إذا اختلفت.
3. ملفات `gradlew` غير موجودة هنا. أسهل طريقة: حمّل Template من https://fabricmc.net/develop/template ثم انسخ مجلد `src` وملفات `build.gradle`, `gradle.properties`, `LICENSE` فوقه، أو شغّل `gradle wrapper` إذا عندك Gradle مثبت.
4. نفّذ `./gradlew build`، والملف الجاهز للنشر في `build/libs/markpoint-1.0.0.jar` (لا ترفع `-sources.jar`).

## الأزرار الافتراضية (قابلة للتغيير من Controls)

| الزر | الوظيفة |
|---|---|
| V | فتح عجلة الإشارات (اضغط على النوع، أو على X بالوسط لحذف إشاراتك) |
| Z | إشارة سريعة بالنوع المفضل |
| X | حذف الإشارة اللي توجّه عليها |
| K | إعدادات المود |

## ملفات الإعدادات

- `config/markpoint-client.properties`: إعدادات اللاعب.
- `config/markpoint-server.properties`: صلاحيات المشاركة (shareEnabled, maxMarksPerPlayer, maxDurationSec, allowPermanent, maxRange).

## النشر على Modrinth

- Project type: Mod. Loader: Fabric. Game version: 1.21.11. Environment: Client and server (client required غير لازم؛ المود يعمل بدون السيرفر محلياً).
- Dependency: Fabric API (Required).
- License: MIT. الوصف: انسخ `MODRINTH_DESCRIPTION.md`.
- الأيقونة: `src/main/resources/assets/markpoint/icon.png`.
