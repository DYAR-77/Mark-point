package com.markpoint.network;

import com.markpoint.MarkData;
import com.markpoint.MarkPointMod;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Used both client->server (create request) and server->client (mark broadcast). */
public record MarkPayload(MarkData data) implements CustomPayload {
	public static final CustomPayload.Id<MarkPayload> ID =
			new CustomPayload.Id<>(Identifier.of(MarkPointMod.MOD_ID, "mark"));

	public static final PacketCodec<PacketByteBuf, MarkPayload> CODEC = PacketCodec.of(
			(payload, buf) -> payload.data.write(buf),
			buf -> new MarkPayload(MarkData.read(buf)));

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
