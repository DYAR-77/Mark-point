package com.markpoint.network;

import com.markpoint.MarkPointMod;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.UUID;

/** Used both client->server (remove request) and server->client (mark removed). */
public record RemovePayload(UUID id) implements CustomPayload {
	public static final CustomPayload.Id<RemovePayload> ID =
			new CustomPayload.Id<>(Identifier.of(MarkPointMod.MOD_ID, "remove"));

	public static final PacketCodec<PacketByteBuf, RemovePayload> CODEC = PacketCodec.of(
			(payload, buf) -> buf.writeUuid(payload.id),
			buf -> new RemovePayload(buf.readUuid()));

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
