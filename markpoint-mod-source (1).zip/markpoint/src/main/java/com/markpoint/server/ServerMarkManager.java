package com.markpoint.server;

import com.markpoint.MarkData;
import com.markpoint.MarkType;
import com.markpoint.network.MarkPayload;
import com.markpoint.network.RemovePayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public final class ServerMarkManager {
	private record Entry(MarkData data, long expiresAt) {
	}

	private static final Map<UUID, Entry> MARKS = new LinkedHashMap<>();
	private static ServerConfig cfg = new ServerConfig();

	private ServerMarkManager() {
	}

	public static void init() {
		ServerLifecycleEvents.SERVER_STARTING.register(server -> {
			MARKS.clear();
			cfg = ServerConfig.load();
		});
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> MARKS.clear());

		ServerPlayNetworking.registerGlobalReceiver(MarkPayload.ID,
				(payload, ctx) -> onCreate(ctx.player(), ctx.server(), payload.data()));
		ServerPlayNetworking.registerGlobalReceiver(RemovePayload.ID,
				(payload, ctx) -> onRemove(ctx.player(), ctx.server(), payload.id()));

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			if (!cfg.shareEnabled) return;
			long now = System.currentTimeMillis();
			for (Entry e : MARKS.values()) {
				int dur = 0;
				if (e.expiresAt() > 0) {
					dur = (int) Math.max(1, (e.expiresAt() - now + 999) / 1000);
				}
				sender.sendPacket(new MarkPayload(e.data().withDuration(dur)));
			}
		});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			if (server.getTicks() % 20 != 0 || MARKS.isEmpty()) return;
			long now = System.currentTimeMillis();
			Iterator<Entry> it = MARKS.values().iterator();
			while (it.hasNext()) {
				Entry e = it.next();
				if (e.expiresAt() > 0 && now >= e.expiresAt()) {
					it.remove();
					broadcast(server, new RemovePayload(e.data().id()));
				}
			}
		});
	}

	private static void onCreate(ServerPlayerEntity p, MinecraftServer server, MarkData d) {
		if (!cfg.shareEnabled) return;

		double dx = d.x() - p.getX();
		double dy = d.y() - p.getY();
		double dz = d.z() - p.getZ();
		double distSq = dx * dx + dy * dy + dz * dz;
		if (!Double.isFinite(distSq) || distSq > (double) cfg.maxRange * cfg.maxRange) return;

		int dur = Math.max(0, d.durationSec());
		if (dur == 0 && !cfg.allowPermanent) {
			dur = cfg.maxDurationSec > 0 ? Math.min(60, cfg.maxDurationSec) : 60;
		} else if (dur > 0 && cfg.maxDurationSec > 0 && dur > cfg.maxDurationSec) {
			dur = cfg.maxDurationSec;
		}

		String label = d.label() == null ? "" : d.label();
		if (label.length() > MarkData.MAX_LABEL) label = label.substring(0, MarkData.MAX_LABEL);

		int type = Math.floorMod(d.type(), MarkType.values().length);
		UUID owner = p.getUuid();

		// enforce per-player limit: drop the oldest marks of this player
		while (countOf(owner) >= cfg.maxMarksPerPlayer) {
			UUID oldest = null;
			for (Entry e : MARKS.values()) {
				if (e.data().owner().equals(owner)) {
					oldest = e.data().id();
					break;
				}
			}
			if (oldest == null) break;
			MARKS.remove(oldest);
			broadcast(server, new RemovePayload(oldest));
		}

		MarkData clean = new MarkData(UUID.randomUUID(), owner, p.getName().getString(), type,
				d.x(), d.y(), d.z(), label, d.color() | 0xFF000000, dur);
		long expires = dur > 0 ? System.currentTimeMillis() + dur * 1000L : 0;
		MARKS.put(clean.id(), new Entry(clean, expires));
		broadcast(server, new MarkPayload(clean));
	}

	private static void onRemove(ServerPlayerEntity p, MinecraftServer server, UUID id) {
		Entry e = MARKS.get(id);
		if (e == null || !e.data().owner().equals(p.getUuid())) return;
		MARKS.remove(id);
		broadcast(server, new RemovePayload(id));
	}

	private static int countOf(UUID owner) {
		int n = 0;
		for (Entry e : MARKS.values()) {
			if (e.data().owner().equals(owner)) n++;
		}
		return n;
	}

	private static void broadcast(MinecraftServer server, CustomPayload payload) {
		for (ServerPlayerEntity pl : server.getPlayerManager().getPlayerList()) {
			if (ServerPlayNetworking.canSend(pl, payload.getId())) {
				ServerPlayNetworking.send(pl, payload);
			}
		}
	}
}
