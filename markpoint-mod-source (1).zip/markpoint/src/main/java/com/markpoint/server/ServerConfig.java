package com.markpoint.server;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Server-side permissions for sharing marks. File: config/markpoint-server.properties */
public final class ServerConfig {
	public boolean shareEnabled = true;
	public int maxMarksPerPlayer = 10;
	public int maxDurationSec = 600;
	public boolean allowPermanent = true;
	public int maxRange = 4096;

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("markpoint-server.properties");
	}

	public static ServerConfig load() {
		ServerConfig c = new ServerConfig();
		Path p = path();
		if (Files.exists(p)) {
			Properties props = new Properties();
			try (Reader r = Files.newBufferedReader(p)) {
				props.load(r);
				c.shareEnabled = Boolean.parseBoolean(props.getProperty("shareEnabled", "true"));
				c.maxMarksPerPlayer = Math.max(1, parse(props, "maxMarksPerPlayer", 10));
				c.maxDurationSec = Math.max(0, parse(props, "maxDurationSec", 600));
				c.allowPermanent = Boolean.parseBoolean(props.getProperty("allowPermanent", "true"));
				c.maxRange = Math.max(16, parse(props, "maxRange", 4096));
			} catch (IOException ignored) {
			}
		} else {
			c.save();
		}
		return c;
	}

	private static int parse(Properties props, String key, int def) {
		try {
			return Integer.parseInt(props.getProperty(key, String.valueOf(def)).trim());
		} catch (NumberFormatException e) {
			return def;
		}
	}

	public void save() {
		Properties props = new Properties();
		props.setProperty("shareEnabled", String.valueOf(shareEnabled));
		props.setProperty("maxMarksPerPlayer", String.valueOf(maxMarksPerPlayer));
		props.setProperty("maxDurationSec", String.valueOf(maxDurationSec));
		props.setProperty("allowPermanent", String.valueOf(allowPermanent));
		props.setProperty("maxRange", String.valueOf(maxRange));
		try (Writer w = Files.newBufferedWriter(path())) {
			props.store(w, "MarkPoint server config (maxDurationSec 0 = unlimited)");
		} catch (IOException ignored) {
		}
	}
}
