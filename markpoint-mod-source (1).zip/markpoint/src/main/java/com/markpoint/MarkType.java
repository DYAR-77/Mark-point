package com.markpoint;

public enum MarkType {
	LOCATION(0xFF3FA9F5, "location"),
	ENEMY(0xFFE53935, "enemy"),
	DANGER(0xFFFF9800, "danger"),
	RESOURCE(0xFF00E5FF, "resource"),
	CHEST(0xFFFFD54F, "chest"),
	HELP(0xFFE040FB, "help"),
	GOTO(0xFF66BB6A, "goto"),
	CUSTOM(0xFFFFFFFF, "custom");

	public final int defaultColor;
	public final String id;

	MarkType(int defaultColor, String id) {
		this.defaultColor = defaultColor;
		this.id = id;
	}

	public String key() {
		return "markpoint.type." + id;
	}

	public static MarkType byOrdinal(int i) {
		MarkType[] v = values();
		return v[Math.floorMod(i, v.length)];
	}
}
