package com.markpoint;

import net.minecraft.network.PacketByteBuf;

import java.util.UUID;

public record MarkData(UUID id, UUID owner, String ownerName, int type,
					   double x, double y, double z,
					   String label, int color, int durationSec) {

	public static final int MAX_LABEL = 32;

	public void write(PacketByteBuf buf) {
		buf.writeUuid(id);
		buf.writeUuid(owner);
		buf.writeString(ownerName == null ? "" : ownerName, 64);
		buf.writeInt(type);
		buf.writeDouble(x);
		buf.writeDouble(y);
		buf.writeDouble(z);
		buf.writeString(label == null ? "" : label, 64);
		buf.writeInt(color);
		buf.writeInt(durationSec);
	}

	public static MarkData read(PacketByteBuf buf) {
		return new MarkData(
				buf.readUuid(),
				buf.readUuid(),
				buf.readString(64),
				buf.readInt(),
				buf.readDouble(),
				buf.readDouble(),
				buf.readDouble(),
				buf.readString(64),
				buf.readInt(),
				buf.readInt());
	}

	public MarkData withDuration(int seconds) {
		return new MarkData(id, owner, ownerName, type, x, y, z, label, color, seconds);
	}
}
