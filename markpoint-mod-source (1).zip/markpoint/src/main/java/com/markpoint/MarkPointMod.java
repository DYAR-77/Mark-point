package com.markpoint;

import com.markpoint.network.MarkPayload;
import com.markpoint.network.RemovePayload;
import com.markpoint.server.ServerMarkManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

public class MarkPointMod implements ModInitializer {
	public static final String MOD_ID = "markpoint";

	@Override
	public void onInitialize() {
		PayloadTypeRegistry.playC2S().register(MarkPayload.ID, MarkPayload.CODEC);
		PayloadTypeRegistry.playS2C().register(MarkPayload.ID, MarkPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(RemovePayload.ID, RemovePayload.CODEC);
		PayloadTypeRegistry.playS2C().register(RemovePayload.ID, RemovePayload.CODEC);

		ServerMarkManager.init();
	}
}
