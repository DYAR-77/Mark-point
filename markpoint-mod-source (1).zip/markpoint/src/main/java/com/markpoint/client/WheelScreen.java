package com.markpoint.client;

import com.markpoint.MarkType;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Radial wheel: pick a mark type with the mouse. Click the centre to delete your marks. */
public class WheelScreen extends Screen {
	private final Vec3d target;
	private final List<MarkType> types = ClientConfig.enabledTypes();
	private final long opened;

	public WheelScreen(Vec3d target) {
		super(Text.translatable("markpoint.wheel.title"));
		this.target = target;
		this.opened = Util.getMeasuringTimeMs();
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private float progress() {
		if (!ClientConfig.animations) return 1f;
		float t = Math.min(1f, (Util.getMeasuringTimeMs() - opened) / 180f);
		return 1f - (1f - t) * (1f - t) * (1f - t); // ease-out
	}

	/** Index of hovered segment, -1 for centre / nothing. */
	private int hover(double mx, double my) {
		if (types.isEmpty()) return -1;
		double dx = mx - width / 2.0, dy = my - height / 2.0;
		if (Math.hypot(dx, dy) < 22) return -1;
		double a = Math.atan2(dy, dx) + Math.PI / 2;
		double full = Math.PI * 2;
		double seg = full / types.size();
		a = ((a % full) + full) % full;
		return (int) Math.round(a / seg) % types.size();
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		float p = progress();
		int alpha = (int) (0x70 * p);
		ctx.fill(0, 0, width, height, alpha << 24);

		int cx = width / 2, cy = height / 2;
		int n = types.size();
		double radius = 70 * p;
		int hov = hover(mx, my);
		boolean centerHover = Math.hypot(mx - cx, my - cy) < 22;

		// centre button (delete my marks)
		int cbox = 14;
		ctx.fill(cx - cbox - 1, cy - cbox - 1, cx + cbox + 1, cy + cbox + 1, centerHover ? 0xFFFFFFFF : 0xFF000000);
		ctx.fill(cx - cbox, cy - cbox, cx + cbox, cy + cbox, centerHover ? 0xFFB71C1C : 0xFF3A3A3A);
		ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("X"), cx, cy - 4, 0xFFFFFFFF);

		for (int i = 0; i < n; i++) {
			MarkType t = types.get(i);
			double ang = -Math.PI / 2 + i * (Math.PI * 2 / n);
			int ix = cx + (int) Math.round(Math.cos(ang) * radius);
			int iy = cy + (int) Math.round(Math.sin(ang) * radius);
			boolean hv = i == hov;
			int half = hv ? 20 : 17;
			int color = ClientConfig.colors[t.ordinal()] | 0xFF000000;
			ctx.fill(ix - half - 2, iy - half - 2, ix + half + 2, iy + half + 2, hv ? 0xFFFFFFFF : 0xFF000000);
			ctx.fill(ix - half, iy - half, ix + half, iy + half, color);
			if (t == ClientConfig.favoriteType()) {
				ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("*"), ix, iy - half + 3, 0xFF000000);
			}
			if (p > 0.6f) {
				ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable(t.key()), ix, iy + half + 5,
						hv ? 0xFFFFFFFF : 0xFFBBBBBB);
			}
		}
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (click.button() == 0) {
			double mx = click.x(), my = click.y();
			int h = hover(mx, my);
			if (h >= 0) {
				ClientMarks.create(types.get(h), target);
				close();
				return true;
			}
			if (Math.hypot(mx - width / 2.0, my - height / 2.0) < 22) {
				ClientMarks.clearMine();
				close();
				return true;
			}
		}
		close();
		return true;
	}
}
