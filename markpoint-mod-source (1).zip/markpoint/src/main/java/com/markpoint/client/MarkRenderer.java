package com.markpoint.client;

import com.markpoint.MarkData;
import com.markpoint.MarkType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;

public final class MarkRenderer {
	private static final String[] CARDINALS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
	private static final int MARGIN = 14;

	private MarkRenderer() {
	}

	public static void render(DrawContext ctx) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden || ClientMarks.all().isEmpty()) return;
		ClientMarks.prune();

		Vec3d eye = mc.player.getEyePos();
		double yr = Math.toRadians(mc.player.getYaw());
		double pr = Math.toRadians(mc.player.getPitch());
		// camera basis (Minecraft yaw/pitch convention)
		double fx = -Math.sin(yr) * Math.cos(pr), fy = -Math.sin(pr), fz = Math.cos(yr) * Math.cos(pr);
		double rx = -Math.cos(yr), ry = 0, rz = -Math.sin(yr);
		double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;

		int w = ctx.getScaledWindowWidth();
		int h = ctx.getScaledWindowHeight();
		double fov = mc.options.getFov().getValue();
		double focal = (h / 2.0) / Math.tan(Math.toRadians(fov) / 2.0);
		java.util.UUID me = mc.player.getUuid();
		long now = System.currentTimeMillis();
		double pulse = ClientConfig.animations ? 1.0 + 0.12 * Math.sin(Util.getMeasuringTimeMs() / 220.0) : 1.0;

		for (ClientMarks.Mark m : ClientMarks.all()) {
			MarkData d = m.data;
			MarkType type = MarkType.byOrdinal(d.type());
			if (!ClientConfig.enabled(type)) continue;

			double dx = d.x() - eye.x, dy = d.y() - eye.y, dz = d.z() - eye.z;
			double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
			if (dist > ClientConfig.maxDistance) continue;

			double zc = dx * fx + dy * fy + dz * fz;
			double xc = dx * rx + dy * ry + dz * rz;
			double yc = dx * ux + dy * uy + dz * uz;

			double sx = 0, sy = 0;
			boolean onScreen = false;
			if (zc > 0.1) {
				sx = w / 2.0 + xc / zc * focal;
				sy = h / 2.0 - yc / zc * focal;
				onScreen = sx >= MARGIN && sx <= w - MARGIN && sy >= MARGIN && sy <= h - MARGIN;
			}
			if (!onScreen) {
				if (!ClientConfig.showOffscreen) continue;
				double vx = xc, vy = -yc;
				double hx = w / 2.0 - MARGIN, hy = h / 2.0 - MARGIN;
				double len = Math.max(Math.abs(vx) / hx, Math.abs(vy) / hy);
				if (len < 1e-9) {
					vx = 0;
					vy = 1;
					len = 1.0 / hy;
				}
				sx = w / 2.0 + vx / len;
				sy = h / 2.0 + vy / len;
			}

			int color = (d.color() & 0x00FFFFFF) | 0xFF000000;
			int half = Math.max(2, (int) Math.round((onScreen ? 4.0 : 3.0) * ClientConfig.scale * pulse));
			int x = (int) Math.round(sx), y = (int) Math.round(sy);

			ctx.fill(x - half - 1, y - half - 1, x + half + 1, y + half + 1, 0xFF000000);
			ctx.fill(x - half, y - half, x + half, y + half, color);
			ctx.fill(x - 1, y + half + 1, x + 1, y + half + 5, 0xFF000000); // small pin
			ctx.fill(x, y + half + 1, x + 1, y + half + 4, color);

			if (!onScreen) continue;

			// name line (label + owner)
			String name = ClientMarks.displayLabel(d);
			if (ClientConfig.showOwner && !d.owner().equals(me) && !d.ownerName().isEmpty()) {
				name += " (" + d.ownerName() + ")";
			}
			ctx.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(name), x, y - half - 12, color);

			// info line: direction, distance, remaining time
			StringBuilder info = new StringBuilder();
			info.append(cardinal(dx, dz));
			if (ClientConfig.showDistance) info.append("  ").append((int) dist).append("m");
			if (m.expiresAt > 0) {
				long sec = Math.max(0, (m.expiresAt - now + 999) / 1000);
				info.append("  ").append(sec >= 60 ? (sec / 60) + "m" + (sec % 60) + "s" : sec + "s");
			}
			ctx.drawCenteredTextWithShadow(mc.textRenderer, Text.literal(info.toString()),
					x, y + half + 8, 0xFFFFFFFF);
		}
	}

	private static String cardinal(double dx, double dz) {
		double yaw = Math.toDegrees(Math.atan2(-dx, dz));
		int idx = (int) Math.floor((((yaw + 22.5) % 360) + 360) % 360 / 45.0) % 8;
		return CARDINALS[idx];
	}
}
