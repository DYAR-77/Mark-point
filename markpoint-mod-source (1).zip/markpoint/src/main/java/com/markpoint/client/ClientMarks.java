package com.markpoint.client;

import com.markpoint.MarkData;
import com.markpoint.MarkType;
import com.markpoint.network.MarkPayload;
import com.markpoint.network.RemovePayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class ClientMarks {
	public static final class Mark {
		public final MarkData data;
		public final long expiresAt;

		Mark(MarkData data, long expiresAt) {
			this.data = data;
			this.expiresAt = expiresAt;
		}
	}

	private static final Map<UUID, Mark> MARKS = new LinkedHashMap<>();

	private ClientMarks() {
	}

	public static Collection<Mark> all() {
		return MARKS.values();
	}

	public static void add(MarkData d) {
		long exp = d.durationSec() > 0 ? System.currentTimeMillis() + d.durationSec() * 1000L : 0;
		MARKS.put(d.id(), new Mark(d, exp));
		playSound(MarkType.byOrdinal(d.type()));
	}

	public static void remove(UUID id) {
		MARKS.remove(id);
	}

	public static void clear() {
		MARKS.clear();
	}

	public static void prune() {
		long now = System.currentTimeMillis();
		MARKS.values().removeIf(m -> m.expiresAt > 0 && now >= m.expiresAt);
	}

	private static void playSound(MarkType type) {
		if (!ClientConfig.sounds) return;
		float pitch = (type == MarkType.ENEMY || type == MarkType.DANGER) ? 0.7f : 1.3f;
		MinecraftClient.getInstance().getSoundManager().play(
				PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), pitch));
	}

	/** Point the player is looking at (entity, block, or far point in the air). */
	public static Vec3d aimPoint(MinecraftClient mc) {
		if (mc.player == null) return Vec3d.ZERO;
		HitResult hit = mc.player.raycast(256.0, 1.0f, false);
		if (mc.crosshairTarget instanceof EntityHitResult e) {
			return e.getPos();
		}
		if (hit instanceof BlockHitResult b && hit.getType() == HitResult.Type.BLOCK) {
			return Vec3d.ofCenter(b.getBlockPos()).add(0, 1.0, 0);
		}
		return hit.getPos();
	}

	public static void create(MarkType type, Vec3d pos) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;
		String label = type == MarkType.CUSTOM ? ClientConfig.customLabel : "";
		if (label.length() > MarkData.MAX_LABEL) label = label.substring(0, MarkData.MAX_LABEL);
		MarkData d = new MarkData(UUID.randomUUID(), mc.player.getUuid(), mc.player.getName().getString(),
				type.ordinal(), pos.x, pos.y, pos.z, label,
				ClientConfig.colors[type.ordinal()], ClientConfig.duration);
		if (ClientPlayNetworking.canSend(MarkPayload.ID)) {
			ClientPlayNetworking.send(new MarkPayload(d)); // server echoes it back to everyone
		} else {
			add(d); // local-only mark
		}
	}

	public static void clearMine() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;
		UUID me = mc.player.getUuid();
		List<UUID> ids = new ArrayList<>();
		for (Mark m : MARKS.values()) if (m.data.owner().equals(me)) ids.add(m.data.id());
		for (UUID id : ids) requestRemove(id);
	}

	/** Deletes my mark closest to the crosshair (within ~6 degrees). */
	public static void removeLookedAt() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;
		Vec3d eye = mc.player.getEyePos();
		Vec3d look = mc.player.getRotationVec(1.0f);
		UUID me = mc.player.getUuid();
		double best = Math.cos(Math.toRadians(6.0));
		UUID bestId = null;
		for (Mark m : MARKS.values()) {
			if (!m.data.owner().equals(me)) continue;
			Vec3d dir = new Vec3d(m.data.x() - eye.x, m.data.y() - eye.y, m.data.z() - eye.z);
			double len = dir.length();
			if (len < 1e-4) continue;
			double dot = dir.dotProduct(look) / len;
			if (dot > best) {
				best = dot;
				bestId = m.data.id();
			}
		}
		if (bestId != null) requestRemove(bestId);
	}

	private static void requestRemove(UUID id) {
		if (ClientPlayNetworking.canSend(RemovePayload.ID)) {
			ClientPlayNetworking.send(new RemovePayload(id));
		}
		// Local removal covers local-only marks (and is harmless if the server echoes it back).
		MARKS.remove(id);
	}

	public static String displayLabel(MarkData d) {
		if (d.label() != null && !d.label().isEmpty()) return d.label();
		return Text.translatable(MarkType.byOrdinal(d.type()).key()).getString();
	}
}
