package com.markpoint.client;

import com.markpoint.MarkPointMod;
import com.markpoint.network.MarkPayload;
import com.markpoint.network.RemovePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class MarkPointClient implements ClientModInitializer {
	private static KeyBinding wheelKey;
	private static KeyBinding quickKey;
	private static KeyBinding deleteKey;
	private static KeyBinding settingsKey;

	@Override
	public void onInitializeClient() {
		ClientConfig.load();

		KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MarkPointMod.MOD_ID, "main"));
		wheelKey = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.markpoint.wheel", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, category));
		quickKey = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.markpoint.quick", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, category));
		deleteKey = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.markpoint.delete", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, category));
		settingsKey = KeyBindingHelper.registerKeyBinding(
				new KeyBinding("key.markpoint.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

		ClientPlayNetworking.registerGlobalReceiver(MarkPayload.ID,
				(payload, ctx) -> ClientMarks.add(payload.data()));
		ClientPlayNetworking.registerGlobalReceiver(RemovePayload.ID,
				(payload, ctx) -> ClientMarks.remove(payload.id()));
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientMarks.clear());

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player == null) return;
			while (wheelKey.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new WheelScreen(ClientMarks.aimPoint(client)));
				}
			}
			while (quickKey.wasPressed()) {
				if (client.currentScreen == null) {
					ClientMarks.create(ClientConfig.favoriteType(), ClientMarks.aimPoint(client));
				}
			}
			while (deleteKey.wasPressed()) {
				if (client.currentScreen == null) ClientMarks.removeLookedAt();
			}
			while (settingsKey.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new SettingsScreen(null));
				}
			}
		});

		HudRenderCallback.EVENT.register((ctx, tickCounter) -> MarkRenderer.render(ctx));
	}
}
