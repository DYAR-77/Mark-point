package com.markpoint.client;

import com.markpoint.MarkType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.function.Supplier;

public class SettingsScreen extends Screen {
	private final Screen parent;
	private int page = 0; // 0 = general, 1 = mark types
	private int row;

	public SettingsScreen(Screen parent) {
		super(Text.translatable("markpoint.settings.title"));
		this.parent = parent;
	}

	private static Text onOff(boolean v) {
		return Text.translatable(v ? "markpoint.on" : "markpoint.off");
	}

	private void button(int col, int y, int w, Supplier<Text> label, Runnable action) {
		int x = width / 2 - 154 + col * 156;
		addDrawableChild(ButtonWidget.builder(label.get(), b -> {
			action.run();
			clearAndInit();
		}).dimensions(x, y, w, 20).build());
	}

	@Override
	protected void init() {
		int top = 36;
		addDrawableChild(ButtonWidget.builder(Text.translatable("markpoint.settings.page.general"),
				b -> {
					page = 0;
					clearAndInit();
				}).dimensions(width / 2 - 154, 8, 150, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.translatable("markpoint.settings.page.types"),
				b -> {
					page = 1;
					clearAndInit();
				}).dimensions(width / 2 + 2, 8, 150, 20).build());

		if (page == 0) {
			button(0, top, 150, () -> Text.translatable("markpoint.settings.duration", durationText()),
					() -> ClientConfig.duration = ClientConfig.cycle(ClientConfig.DURATIONS, ClientConfig.duration));
			button(1, top, 150, () -> Text.translatable("markpoint.settings.distance", ClientConfig.maxDistance),
					() -> ClientConfig.maxDistance = ClientConfig.cycle(ClientConfig.DISTANCES, ClientConfig.maxDistance));
			button(0, top + 24, 150, () -> Text.translatable("markpoint.settings.scale", ClientConfig.scale),
					() -> ClientConfig.scale = ClientConfig.cycle(ClientConfig.SCALES, ClientConfig.scale));
			button(1, top + 24, 150, () -> Text.translatable("markpoint.settings.sounds", onOff(ClientConfig.sounds)),
					() -> ClientConfig.sounds = !ClientConfig.sounds);
			button(0, top + 48, 150, () -> Text.translatable("markpoint.settings.animations", onOff(ClientConfig.animations)),
					() -> ClientConfig.animations = !ClientConfig.animations);
			button(1, top + 48, 150, () -> Text.translatable("markpoint.settings.showDistance", onOff(ClientConfig.showDistance)),
					() -> ClientConfig.showDistance = !ClientConfig.showDistance);
			button(0, top + 72, 150, () -> Text.translatable("markpoint.settings.showOwner", onOff(ClientConfig.showOwner)),
					() -> ClientConfig.showOwner = !ClientConfig.showOwner);
			button(1, top + 72, 150, () -> Text.translatable("markpoint.settings.showOffscreen", onOff(ClientConfig.showOffscreen)),
					() -> ClientConfig.showOffscreen = !ClientConfig.showOffscreen);
			button(0, top + 96, 150, () -> Text.translatable("markpoint.settings.favorite",
							Text.translatable(ClientConfig.favoriteType().key())),
					() -> ClientConfig.favorite = (ClientConfig.favorite + 1) % MarkType.values().length);
		} else {
			MarkType[] types = MarkType.values();
			for (int i = 0; i < types.length; i++) {
				final MarkType t = types[i];
				int y = top + (i / 2) * 24;
				int col = i % 2;
				int x = width / 2 - 154 + col * 156;
				addDrawableChild(ButtonWidget.builder(
						Text.translatable(t.key()).append(Text.literal(": ")).append(onOff(ClientConfig.enabled(t))),
						b -> {
							ClientConfig.toggle(t);
							clearAndInit();
						}).dimensions(x, y, 100, 20).build());
				final int c = ClientConfig.colors[t.ordinal()];
				addDrawableChild(ButtonWidget.builder(
						Text.literal("██").styled(s -> s.withColor(c & 0xFFFFFF)),
						b -> {
							ClientConfig.colors[t.ordinal()] =
									ClientConfig.cycle(ClientConfig.PALETTE, ClientConfig.colors[t.ordinal()]);
							clearAndInit();
						}).dimensions(x + 104, y, 46, 20).build());
			}
			int fy = top + 4 * 24 + 8;
			TextFieldWidget labelField = new TextFieldWidget(textRenderer, width / 2 - 154, fy, 150, 20,
					Text.translatable("markpoint.settings.customLabel"));
			labelField.setMaxLength(32);
			labelField.setText(ClientConfig.customLabel);
			labelField.setChangedListener(s -> ClientConfig.customLabel = s);
			addDrawableChild(labelField);

			int ci = MarkType.CUSTOM.ordinal();
			TextFieldWidget colorField = new TextFieldWidget(textRenderer, width / 2 + 2, fy, 150, 20,
					Text.translatable("markpoint.settings.customColor"));
			colorField.setMaxLength(6);
			colorField.setText(String.format("%06X", ClientConfig.colors[ci] & 0xFFFFFF));
			colorField.setChangedListener(s -> {
				try {
					if (s.length() == 6) ClientConfig.colors[ci] = Integer.parseInt(s, 16) | 0xFF000000;
				} catch (NumberFormatException ignored) {
				}
			});
			addDrawableChild(colorField);
		}

		addDrawableChild(ButtonWidget.builder(Text.translatable("markpoint.settings.done"), b -> close())
				.dimensions(width / 2 - 100, height - 28, 200, 20).build());
	}

	private Text durationText() {
		if (ClientConfig.duration == 0) return Text.translatable("markpoint.permanent");
		int d = ClientConfig.duration;
		return Text.literal(d >= 60 ? (d / 60) + "m" : d + "s");
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		super.render(ctx, mx, my, delta);
		if (page == 1) {
			int fy = 36 + 4 * 24 + 8;
			ctx.drawTextWithShadow(textRenderer, Text.translatable("markpoint.settings.customLabel"),
					width / 2 - 154, fy - 11, 0xFFAAAAAA);
			ctx.drawTextWithShadow(textRenderer, Text.translatable("markpoint.settings.customColor"),
					width / 2 + 2, fy - 11, 0xFFAAAAAA);
		}
	}

	@Override
	public void removed() {
		ClientConfig.save();
	}

	@Override
	public void close() {
		if (client != null) client.setScreen(parent);
	}
}
