package com.markpoint.client;

import com.markpoint.MarkType;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/** Client settings. File: config/markpoint-client.properties */
public final class ClientConfig {
	public static final int[] DURATIONS = {5, 15, 30, 60, 300, 0}; // 0 = permanent
	public static final int[] DISTANCES = {64, 128, 256, 512, 1000, 2000};
	public static final float[] SCALES = {0.75f, 1.0f, 1.25f, 1.5f, 2.0f};
	public static final int[] PALETTE = {
			0xFF3FA9F5, 0xFFE53935, 0xFFFF9800, 0xFF00E5FF, 0xFFFFD54F,
			0xFFE040FB, 0xFF66BB6A, 0xFFFFFFFF, 0xFFFF4081, 0xFF8D6E63
	};

	public static int maxDistance = 1000;
	public static float scale = 1.0f;
	public static int duration = 30;
	public static boolean sounds = true;
	public static boolean animations = true;
	public static boolean showDistance = true;
	public static boolean showOwner = true;
	public static boolean showOffscreen = true;
	public static int enabledMask = 0xFF;
	public static int favorite = 0;
	public static String customLabel = "Mark";
	public static final int[] colors = new int[MarkType.values().length];

	static {
		resetColors();
	}

	private ClientConfig() {
	}

	private static void resetColors() {
		for (MarkType t : MarkType.values()) colors[t.ordinal()] = t.defaultColor;
	}

	public static boolean enabled(MarkType t) {
		return ((enabledMask >> t.ordinal()) & 1) != 0;
	}

	public static void toggle(MarkType t) {
		enabledMask ^= (1 << t.ordinal());
		if (enabledMask == 0) enabledMask |= (1 << t.ordinal()); // keep at least one
	}

	public static List<MarkType> enabledTypes() {
		List<MarkType> list = new ArrayList<>();
		for (MarkType t : MarkType.values()) if (enabled(t)) list.add(t);
		return list;
	}

	public static MarkType favoriteType() {
		return MarkType.byOrdinal(favorite);
	}

	public static int cycle(int[] arr, int cur) {
		int idx = -1;
		for (int i = 0; i < arr.length; i++) if (arr[i] == cur) idx = i;
		return arr[(idx + 1) % arr.length];
	}

	public static float cycle(float[] arr, float cur) {
		int idx = -1;
		for (int i = 0; i < arr.length; i++) if (Math.abs(arr[i] - cur) < 0.001f) idx = i;
		return arr[(idx + 1) % arr.length];
	}

	private static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("markpoint-client.properties");
	}

	private static int i(Properties p, String k, int d) {
		try {
			return Integer.parseInt(p.getProperty(k, String.valueOf(d)).trim());
		} catch (NumberFormatException e) {
			return d;
		}
	}

	private static float f(Properties p, String k, float d) {
		try {
			return Float.parseFloat(p.getProperty(k, String.valueOf(d)).trim());
		} catch (NumberFormatException e) {
			return d;
		}
	}

	private static boolean b(Properties p, String k, boolean d) {
		return Boolean.parseBoolean(p.getProperty(k, String.valueOf(d)));
	}

	public static void load() {
		Path path = path();
		if (!Files.exists(path)) {
			save();
			return;
		}
		Properties p = new Properties();
		try (Reader r = Files.newBufferedReader(path)) {
			p.load(r);
		} catch (IOException e) {
			return;
		}
		maxDistance = i(p, "maxDistance", maxDistance);
		scale = f(p, "scale", scale);
		duration = i(p, "duration", duration);
		sounds = b(p, "sounds", sounds);
		animations = b(p, "animations", animations);
		showDistance = b(p, "showDistance", showDistance);
		showOwner = b(p, "showOwner", showOwner);
		showOffscreen = b(p, "showOffscreen", showOffscreen);
		enabledMask = i(p, "enabledMask", enabledMask);
		if (enabledMask == 0) enabledMask = 0xFF;
		favorite = Math.floorMod(i(p, "favorite", favorite), MarkType.values().length);
		customLabel = p.getProperty("customLabel", customLabel);
		for (MarkType t : MarkType.values()) {
			colors[t.ordinal()] = i(p, "color." + t.id, t.defaultColor) | 0xFF000000;
		}
	}

	public static void save() {
		Properties p = new Properties();
		p.setProperty("maxDistance", String.valueOf(maxDistance));
		p.setProperty("scale", String.valueOf(scale));
		p.setProperty("duration", String.valueOf(duration));
		p.setProperty("sounds", String.valueOf(sounds));
		p.setProperty("animations", String.valueOf(animations));
		p.setProperty("showDistance", String.valueOf(showDistance));
		p.setProperty("showOwner", String.valueOf(showOwner));
		p.setProperty("showOffscreen", String.valueOf(showOffscreen));
		p.setProperty("enabledMask", String.valueOf(enabledMask));
		p.setProperty("favorite", String.valueOf(favorite));
		p.setProperty("customLabel", customLabel);
		for (MarkType t : MarkType.values()) {
			p.setProperty("color." + t.id, String.valueOf(colors[t.ordinal()]));
		}
		try (Writer w = Files.newBufferedWriter(path())) {
			p.store(w, "MarkPoint client config (duration 0 = permanent)");
		} catch (IOException ignored) {
		}
	}
}
